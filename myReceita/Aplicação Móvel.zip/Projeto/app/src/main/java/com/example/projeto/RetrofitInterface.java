package com.example.projeto;

import com.google.gson.JsonObject;

import org.w3c.dom.Comment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FieldMap;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

public interface RetrofitInterface {

    @POST("/login")
    Call<Void> executeLogin (@QueryMap HashMap<String, String> map); //Vai ter os dados de Login

    @POST("/signup")
    Call<Void> executeSignup (@QueryMap HashMap<String, String> map); //Vai ter os dados de Registo


    @POST("receita")
    Call<Receitas> pedirReceita( @Body Receitas receitas );

}
