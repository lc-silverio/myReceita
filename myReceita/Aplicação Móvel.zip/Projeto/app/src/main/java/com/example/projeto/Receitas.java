package com.example.projeto;

public class Receitas {

    private String id;

    private String nome;
    private String precoMaximo;
    private String formaFarmaceutica;
    private String dosagem;
    private String embalagem;

    public Receitas(String nome, String precoMaximo, String formaFarmaceutica, String dosagem, String embalagem) {
        this.nome = nome;
        this.precoMaximo = precoMaximo;
        this.formaFarmaceutica = formaFarmaceutica;
        this.dosagem = dosagem;
        this.embalagem = embalagem;
    }


    public String getId(){return id;}


    public String getNome() {
        return nome;
    }

    public String getPrecoMaximo() {
        return precoMaximo;
    }

    public String getFormaFarmaceutica() {
        return formaFarmaceutica;
    }

    public String getDosagem() {
        return dosagem;
    }

    public String getEmbalagem() {
        return embalagem;
    }
}
