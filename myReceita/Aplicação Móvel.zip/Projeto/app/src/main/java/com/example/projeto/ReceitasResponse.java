package com.example.projeto;

import java.util.List;

public class ReceitasResponse {

    private List<Receitas> receitas;

    public ReceitasResponse(List<Receitas> receitas) {
        this.receitas = receitas;
    }

    public List<Receitas> getReceitas() {
        return receitas;
    }

    public void setReceitas(List<Receitas> receitas) {
        this.receitas = receitas;
    }

}
