package com.example.projeto;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;



public class menu extends AppCompatActivity {

    private Retrofit retrofit;
    private RetrofitInterface retrofitInterface;
    private String BASE_URL = "http://10.0.2.2:3000";
    private static String numeroUtente;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        retrofitInterface = retrofit.create(RetrofitInterface.class);

        numeroUtente = getIntent().getStringExtra("EXTRA_UTENTE");


        TextView textView = (TextView) findViewById(R.id.boasVindas);
        textView.setText("Cartão de Utente nº " + numeroUtente);


        showReceita();




    }




    private void showReceita() {

        ImageButton verReceitas = this.findViewById(R.id.refresh);

        verReceitas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Receitas receitas = new Receitas(
                        numeroUtente,
                        "",
                        "",
                        "",
                        ""
                );

                TextView textView1 = (TextView) findViewById(R.id.r1);
                textView1.setText(""); //set text for text view
                TextView textView2 = (TextView) findViewById(R.id.r2);
                textView2.setText(""); //set text for text view
                TextView textView3 = (TextView) findViewById(R.id.r3);
                textView3.setText(""); //set text for text view
                TextView textView4 = (TextView) findViewById(R.id.r4);
                textView4.setText(""); //set text for text view
                TextView textView5 = (TextView) findViewById(R.id.r5);
                textView5.setText(""); //set text for text view
                /*
                TextView textView6 = (TextView) findViewById(R.id.r6);
                textView6.setText(""); //set text for text view
                TextView textView7 = (TextView) findViewById(R.id.r7);
                textView7.setText(""); //set text for text view
                TextView textView8 = (TextView) findViewById(R.id.r8);
                textView8.setText(""); //set text for text view
                TextView textView9 = (TextView) findViewById(R.id.r9);
                textView9.setText(""); //set text for text view
                TextView textView10 = (TextView) findViewById(R.id.r10);
                textView10.setText(""); //set text for text view
                TextView textView11 = (TextView) findViewById(R.id.r11);
                textView11.setText(""); //set text for text view
                 */


                Call<Receitas> call = retrofitInterface.pedirReceita(receitas);
                    call.enqueue(new Callback<Receitas>() {
                        @Override
                        public void onResponse(Call<Receitas> call, Response<Receitas> response) {

                            /* String que vamos dividir */
                            String id = response.body().getId();
                            String nomes = response.body().getNome();
                            String precos = response.body().getPrecoMaximo();
                            String formas = response.body().getFormaFarmaceutica();
                            String dosagens = response.body().getDosagem();
                            String embalagens = response.body().getEmbalagem();

                            /* Array que guarda string. */
                            String[] idsArray;
                            String[] nomesArray;
                            String[] precosArray;
                            String[] formasArray;
                            String[] dosagensArray;
                            String[] embalagensArray;

                            /* limitador */
                            String delimiter = "!!";

                            /* Separar a string com base no limitador e colocar no array */
                            idsArray = id.split(delimiter);
                            nomesArray = nomes.split(delimiter);
                            precosArray = precos.split(delimiter);
                            formasArray = formas.split(delimiter);
                            dosagensArray = dosagens.split(delimiter);
                            embalagensArray = embalagens.split(delimiter);

                            if(idsArray[0].equalsIgnoreCase("")){
                                TextView textView = (TextView) findViewById(R.id.r1);
                                textView.setText("\n\nNão tem nenhuma receita válida.\nMais informação ligue 210 000 000\nou\nenvie um mail para o info@myreceita.pt\nObrigado\n\n"); //set text for text view

                            }else {
                                for (int i = 0; i < nomesArray.length; i++) {

                                    System.out.println("Nº Receita: " + idsArray[i]);
                                    System.out.println("Nome Medicamento: " + nomesArray[i]);
                                    System.out.println("Preço Máximo: " + precosArray[i]);
                                    System.out.println("Forma Farmaceutica: " + formasArray[i]);
                                    System.out.println("Toma: " + dosagensArray[i]);
                                    System.out.println("Quantidade: " + embalagensArray[i]);

                                    if (i == 0) {
                                        TextView textView = (TextView) findViewById(R.id.r1);
                                        textView.setText("\n(Para mais informação ligue 210 000 000\nou envie um mail para o info@myreceita.pt)\n--------------------------------------\nNº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------"); //set text for text view
                                    } else if (i == 1) {
                                        TextView textView = (TextView) findViewById(R.id.r2);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 2) {
                                        TextView textView = (TextView) findViewById(R.id.r3);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 3) {
                                        TextView textView = (TextView) findViewById(R.id.r4);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 4) {
                                        TextView textView = (TextView) findViewById(R.id.r5);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } /*else if (i == 5) {
                                        TextView textView = (TextView) findViewById(R.id.r6);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 6) {
                                        TextView textView = (TextView) findViewById(R.id.r7);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 7) {
                                        TextView textView = (TextView) findViewById(R.id.r8);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 8) {
                                        TextView textView = (TextView) findViewById(R.id.r9);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n--------------------------------------\n"); //set text for text view
                                    } else if (i == 9) {
                                        TextView textView = (TextView) findViewById(R.id.r10);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n-------------------\n"); //set text for text view
                                    } else if (i == 10) {
                                        TextView textView = (TextView) findViewById(R.id.r11);
                                        textView.setText("Nº Receita: " + idsArray[i] + "\nNome: " + nomesArray[i] + "\nPreço Máximo: " + precosArray[i] + "€\nForma Farmaceutica: " + formasArray[i] + "\nPosologia: " + dosagensArray[i] + "\nQuantidade: " + embalagensArray[i] + "\n"); //set text for text view
                                    }*/



                                }
                            }


                            Toast.makeText(menu.this, "work", Toast.LENGTH_LONG).show();

                        }

                        @Override
                        public void onFailure(Call<Receitas> call, Throwable t) {
                            Toast.makeText(menu.this, "error", Toast.LENGTH_LONG).show();
                        }




                    });


            }
        });

    }



}