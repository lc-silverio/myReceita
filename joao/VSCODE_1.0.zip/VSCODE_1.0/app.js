const express = require("express");
const mariadb = require('mariadb');
const bodyParser = require('body-parser');
var jsonParser = bodyParser.json()
//
//
const app = express();
const PORTA = 3000;
//
//
//Usamos para realizar a connexao à BD cada vez que existe uma comunicação rest
const pool = mariadb.createPool({
  host: 'localhost', 
  user:'root', 
  password: 'admin',
  database: 'myreceita'
});
//
//
//------------------------- JOAO -------------------------------------------------------------------------------------------------------------------------------------
//
//
//------------------------------------------------------------->   UTENTES
//Signup de utentes
app.post('/signup', (req, res) => {

    const newUser = {
        numeroUtente: req.query.numeroDeUtente,
        nome: req.query.nome,
        palavraPasse: req.query.palavraPasse,
        nif: req.query.nif,
        mail: req.query.mail,
        telemovel: req.query.telemovel
    }


    
    async function registo(){
      try{
        let conn = await pool.getConnection();
        const selecionar = "SELECT cartaoUtente FROM paciente WHERE cartaoUtente = "+ newUser.numeroUtente + ";";
        let rows = await conn.query(selecionar);
        console.log("Select Executado.");
        if(rows[0] == null){
          const string = "INSERT INTO paciente values ("+ newUser.numeroUtente + ", '" + newUser.nome + "', '" + newUser.palavraPasse + "', " + newUser.nif + ", '" + newUser.mail  + "', " + newUser.telemovel + ")";
          console.log("Insert inicio.");
          let respo = await conn.query(string);
          console.log("Insert fim.");
          res.status(200).send();
        }else{
          console.log("Insert Não Executado.");
          res.status(400).send();
        }
      }catch(err){
  
      }
    }

    registo();
    
});
//
//
//-------------------------
//
//
//Login de utentes
app.post('/login', (req, res) => {

  const newUser = {
      numeroUtente: req.query.numeroUtente,
      password: req.query.password,
  }


  
  async function autenticar(){
    try{
      let conn = await pool.getConnection();
      const selecionar = "SELECT cartaoUtente FROM paciente WHERE cartaoUtente = "+ newUser.numeroUtente + " AND pass = '" + newUser.password + "';";
      let rows = await conn.query(selecionar);
      console.log("Select Executado.");
      if(rows[0] != null){
        console.log("Conta autenticada.");
        res.status(200).send();
      }else{
        console.log("Numero de Utente ou Palavra Passe incorreta.");
        console.log("ERRO X");
        res.status(400).send();
      }
    }catch(err){
      console.log("Numero de Utente ou Palavra Passe incorreta.");
      console.log("ERRO Y");
      res.status(400).send();
    }
  }

  autenticar();
  
});
//
//
//-------------------------
//
//
//-------------------------
//
//
app.post('/receita', jsonParser, (req, res) => {
  
  //Inicio - Obter segundos desde 1970
  var d = new Date(); 
  var seconds = Math.round(d.getTime() / 1000);
  console.log(seconds); 
  //Fim

  const newUser = {
      numeroUtente: req.body.nome
  }

  async function verReceitas(){
    try{
      let conn = await pool.getConnection();
      const selecionar = "SELECT receita.idMedicamento, receita.nReceita, receita.dataEmissao, receita.duracaoMedicamento, receita.primeiroLevantamento, receita.renova, receita.ultimoLevantamento, medicamento.nome, medicamento.formaFarmaceutica, receita.posologia, receita.quantidade, medicamento.precoMaximo FROM medicamento join receita ON receita.idMedicamento = medicamento.idMedicamento WHERE receita.cartaoUtente = "+ newUser.numeroUtente + ";";
      let rows = await conn.query(selecionar);
      console.log("Select Executado. (1) \n");

      let idString = "";
      let nomeString = "";
      let precoString = "";
      let formaFarmaceuticaString = "";
      let dosagemString = "";
      let embalagemString = "";
      let validadeReceita = "";
      let dataEmissaoString = "";
      let duracaoMedicamentoString = "";
      let primeiroLevantamentoString = "";
      let ultimoLevantamentoString = "";
      let renovaString = "";

      for(let i = 0; i < rows.length; i++){

        if(rows[i].renova === "t"){
          //verificamos se ja foi efetuado o primeiro levantamento da receita
          if(rows[i].primeiroLevantamento === "t"){
            //seconds - 432000 para disponibilizar a receita 5 dias antes de acabar
            if(rows[i].ultimoLevantamento + rows[i].duracaoMedicamento > (seconds - 432000)){
              idString += rows[i].nReceita + "!!";
              nomeString += rows[i].nome + "!!";
              precoString += rows[i].precoMaximo + "!!";
              formaFarmaceuticaString += rows[i].formaFarmaceutica + "!!";
              dosagemString += rows[i].posologia + "!!";
              embalagemString += rows[i].quantidade + "!!";
            }  
          }else{
            //seconds - 432000 para disponibilizar a receita 5 dias antes de acabar
            if(rows[i].dataEmissao + rows[i].duracaoMedicamento > (seconds- 432000)){
              idString += rows[i].nReceita + "!!";
              nomeString += rows[i].nome + "!!";
              precoString += rows[i].precoMaximo + "!!";
              formaFarmaceuticaString += rows[i].formaFarmaceutica + "!!";
              dosagemString += rows[i].posologia + "!!";
              embalagemString += rows[i].quantidade + "!!";
            }
          }
        }else{
          //Verifica se o dia atual é superior à validade da receita
          if(seconds > rows[i].validadeReceita){
            //Verifica se nunca foi levantada
            if(rows[i].primeiroLevantamento === "f"){
              idString += rows[i].nReceita + "!!";
              nomeString += rows[i].nome + "!!";
              precoString += rows[i].precoMaximo + "!!";
              formaFarmaceuticaString += rows[i].formaFarmaceutica + "!!";
              dosagemString += rows[i].posologia + "!!";
              embalagemString += rows[i].quantidade + "!!";  
            }
          }
        }
        
      }


      //console.log(idString + "\n" +nomeString + "\n" + precoString + "\n" + formaFarmaceuticaString + "\n" + dosagemString + "\n" + embalagemString);

      res.json({'status':'200', id: idString, nome: nomeString, precoMaximo: precoString, formaFarmaceutica: formaFarmaceuticaString, dosagem: dosagemString, embalagem: embalagemString});
      pool.end;
    }
    catch(err){
      console.log("Numero de Utente ou Palavra Passe incorreta.");
      console.log("ERRO CATCH (1)");
      console.log(err);
      res.status(400).send();
    }
  }


  verReceitas();
  
});
//------------------------------------------------------------->   FIM DE UTENTES
//
//
//------------------------- LUIS  -------------------------------------------------------------------------------------------------------------------------------------
//
//
//------------------------------------------------------------->   MEDICOS
//REGISTO DE UMA RECEITA
app.post('/receitaMed', (req, res) => {

  const newReceita = {
      numeroDeUtente: req.query.numeroDeUtente,
      idMedico: req.query.idMedico,
      idMedicamento: req.query.idMedicamento,
      posologia: req.query.posologia,
      nif: req.query.nif,
      renova: req.query.renova,
      quantidade: req.query.quantidade,
      diariamente: req.query.diariamente
  }


  
  async function registoMedicamento(){
    try{
      let conn = await pool.getConnection();
      
      //Para verificar ultimo numero de receita inserido
      const selecionar = "SELECT MAX(nReceita)FROM receita;";
      let rows = await conn.query(selecionar);
      console.log("Select Executado.");
      let nReceita = row[0].nReceita + 1;
      //Fim

      //Para verificar a forma farmaceutica, dosagem e embalagem do medicamento da receita --> (Necessario para contas duracaoMedicamento)
      const selecionar1 = "SELECT formaFarmaceutica, dosagem, embalagem FROM medicamento WHERE idMedicamento = " + newReceita.idMedicamento + ";";
      let rows1 = await conn.query(selecionar1);
      console.log("Select 1 Executado.");
      let formaFarmaceutica = rows1[0].formaFarmaceutica;
      if(formaFarmaceutica === "Comprimido"){
        let dias = rows1[0].embalagem / newReceita.diariamente;
        var duracaoMedicamento = dias * 86400;
      }else{
        //Assumimos 15ml como toma de uma colher de sopa --> (calculado em excesso para os que têm toma inferior)
        let tomaDiaria = 15 * newReceita.diariamente;
        let dias = rows1[0].dosagem / tomaDiaria;
        var duracaoMedicamento = dias * 86400;
      }
      //Fim
      
      //Inicio - Obter segundos desde 1970
      var d = new Date(); 
      var dataEmissao = Math.round(d.getTime() / 1000);
      console.log("Data Emissão:" + dataEmissao); 
      //Fim

      //Se nao renovar é necessário ver a validade da receita
      if(newReceita.renova === "t"){
        var validadeReceita = 0;
      }else{
        var validadeReceita = dataEmissao + ( duracaoMedicamento * newReceita.quantidade);
      }

      if(rows[0] == null){
        const string = "INSERT INTO receita values ("+ NULL + ", " + nReceita + ", " + newReceita.numeroDeUtente + ", " + newReceita.idMedico + ", " + newReceita.idMedicamento  + ", '" + newReceita.posologia + "', " + newReceita.nif + ", " + dataEmissao + ", " + duracaoMedicamento + ", " + validadeReceita + ", " + 0 + ", 'f', '" + newReceita.renova + "', " + newReceita.quantidade + ")";
        console.log("Insert inicio.");
        let respo = await conn.query(string);
        console.log("Insert fim.");
        res.status(200).send();
      }else{
        console.log("Insert Não Executado.");
        res.status(400).send();
      }
    }catch(err){

    }
  }

  registoMedicamento();
  
});





//------------------------------------------------------------->   FIM DE MEDICOS
//
//
//------------------------------------------------------------->   FARMACEUTICOS




//------------------------------------------------------------->   FIM DE FARMACEUTICOS
//
//
//-------------------------
//
//
//-------------------------
//
//
//Mantem o rest a funcionar através da porta 3000 usando express
app.listen(PORTA);
console.log("Server Ligado");
//
//
//
//